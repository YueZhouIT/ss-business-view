import React from 'react';
import {
    User as UserIcon, Settings,
    MapPin, Users, FileText, MessageSquare, Radio, Menu
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'; // 用于移动端侧边栏

interface DashboardLayoutProps {
    children: React.ReactNode;
}

const DashboardLayout = ({ children }: DashboardLayoutProps) => {
    return (
        <div className="flex flex-col min-h-screen bg-background">
            {/* ================= Header 区域 (对应草图顶部 Header) ================= */}
            <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 flex items-center h-16 px-4 justify-between gap-4">

                {/* 左侧：Logo 和 过滤器 */}
                <div className="flex items-center gap-6 md:gap-8">
                    <div className="text-xl font-bold uppercase tracking-wider">LOGO</div>

                    {/* 桌面端过滤器栏 */}
                    <div className="hidden md:flex items-center gap-3">
                        <FilterSelect placeholder="Area" />
                        <FilterSelect placeholder="Country" />
                        <FilterSelect placeholder="Window" />

                        <div className="flex items-center gap-2 ml-4 text-sm text-muted-foreground border-l pl-4">
                            <StatusBadge label="Customer: xxx" />
                            <StatusBadge label="Account: xxx" />
                        </div>
                    </div>
                </div>

                {/* 右侧：按钮和用户菜单 */}
                <div className="flex items-center gap-3">
                    <div className="hidden md:flex gap-2">
                        <Button variant="outline" size="sm">A</Button>
                        <Button variant="outline" size="sm">B</Button>
                    </div>

                    {/* 用户头像下拉菜单 */}
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                                <Avatar className="h-8 w-8">
                                    <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
                                    <AvatarFallback>U</AvatarFallback>
                                </Avatar>
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="w-56" align="end" forceMount>
                            <DropdownMenuLabel className="font-normal">
                                <div className="flex flex-col space-y-1">
                                    <p className="text-sm font-medium leading-none">User xxx</p>
                                    <p className="text-xs leading-none text-muted-foreground">user@example.com</p>
                                </div>
                            </DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>Log out</DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>

                    {/* 移动端菜单触发器 (小屏幕显示) */}
                    <Sheet>
                        <SheetTrigger asChild>
                            <Button variant="ghost" size="icon" className="md:hidden shrink-0">
                                <Menu className="h-5 w-5" />
                                <span className="sr-only">Toggle navigation menu</span>
                            </Button>
                        </SheetTrigger>
                        <SheetContent side="left">
                            <SidebarContent />
                        </SheetContent>
                    </Sheet>
                </div>
            </header>

            {/* ================= 中间主体区域 (Flex 布局) ================= */}
            <div className="flex flex-1 overflow-hidden relative">

                {/* ============ 左侧 Sidebar (对应草图左侧导航) ============ */}
                <aside className="hidden w-56 flex-col border-r bg-muted/10 md:flex">
                    <SidebarContent />
                </aside>

                {/* ============ 主内容区域 (用于放置 DashboardPage) ============ */}
                <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-muted/5">
                    {children}
                </main>
            </div>

            {/* ================= Footer 区域 (对应草图底部 Footer) ================= */}
            <footer className="border-t py-2 px-4 text-center text-sm text-muted-foreground h-10 flex items-center justify-center">
                Footer Content © 2024
            </footer>
        </div>
    );
};


// --- 辅助组件 ---

// 侧边栏菜单内容封装
const SidebarContent = () => (
    <div className="flex h-full max-h-screen flex-col gap-2">
        <div className="flex-1 overflow-auto py-4">
            <nav className="grid items-start px-2 text-sm font-medium lg:px-4 space-y-1">
                <NavItem icon={<Radio />} label="Live Events" active />
                <NavItem icon={<Users />} label="Customers" />
                <NavItem icon={<FileText />} label="Accounts" />
                <NavItem icon={<UserIcon />} label="Users" />
                <NavItem icon={<MessageSquare />} label="AI chat" />
                <NavItem icon={<MapPin />} label="GPS Insight" />
            </nav>
        </div>
        <div className="mt-auto p-4 border-t">
            <NavItem icon={<Settings />} label="Staff User" />
        </div>
    </div>
)

// 单个导航链接项
const NavItem = ({ icon, label, active }: { icon: React.ReactNode; label: string; active?: boolean }) => {
    return (
        <a
            href="#"
            className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
                active ? 'bg-muted text-primary font-semibold' : 'text-muted-foreground'
            }`}
        >
            {/* 关键修改在这里：添加了 <{ className?: string }> 泛型 */}
            {React.isValidElement(icon) &&
                React.cloneElement(icon as React.ReactElement<{ className?: string }>, {
                    className: 'h-4 w-4'
                })
            }
            {label}
        </a>
    );
};

// Header 上的简易下拉选择框封装
const FilterSelect = ({ placeholder }: { placeholder: string }) => (
    <Select>
        <SelectTrigger className="w-[100px] h-8 text-xs">
            <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
            <SelectItem value="opt1">Option 1</SelectItem>
            <SelectItem value="opt2">Option 2</SelectItem>
        </SelectContent>
    </Select>
);

// Header 上的状态标签封装
const StatusBadge = ({ label }: { label: string }) => (
    <Badge variant="secondary" className="text-xs font-normal bg-muted/50 text-muted-foreground hover:bg-muted/50 whitespace-nowrap">
        {label}
    </Badge>
)

export default DashboardLayout;