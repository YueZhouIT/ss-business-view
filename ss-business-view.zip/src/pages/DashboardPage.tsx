import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.tsx';
import { Input } from '@/components/ui/input.tsx';
import { Search } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// 模拟折线图数据
const lineChartData = [
    { name: 'Mon', value: 400 }, { name: 'Tue', value: 300 },
    { name: 'Wed', value: 500 }, { name: 'Thu', value: 280 },
    { name: 'Fri', value: 590 }, { name: 'Sat', value: 320 }, { name: 'Sun', value: 450 },
];

// 模拟 Top Requests 数据
const topRequestsData = [
    { id: 1, request: "API call failed for user X", count: 124 },
    { id: 2, request: "GPS signal lost in Zone B", count: 98 },
    { id: 3, request: "Account sync timeout", count: 85 },
    { id: 4, request: "AI chat not responding", count: 65 },
    { id: 5, request: "Login issues from IP 192...", count: 44 },
    // 可以添加更多...
];


const DashboardPage = () => {
    return (
        // 使用 Grid 布局还原草图结构。
        // md:grid-cols-3 表示中等屏幕以上分为3列。
        // h-[calc(100vh-8rem)] 是为了让内容区域大致填满屏幕高度 (减去 header 和 footer 的高度)
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 h-full md:h-[calc(100vh-8rem)]">

            {/* ================= 左侧：Top Requests (占 1/3 宽度, 占满高度) ================= */}
            <Card className="md:col-span-1 flex flex-col h-full overflow-hidden">
                <CardHeader>
                    <CardTitle>Top Requests</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 overflow-auto">
                    {/* 这里用一个简单的列表模拟 Table，你也可以用 Shadcn 的 Table 组件 */}
                    <div className="space-y-4">
                        {topRequestsData.map(item => (
                            <div key={item.id} className="flex items-center justify-between border-b pb-3 last:border-0">
                                <span className="text-sm font-medium truncate mr-2">{item.request}</span>
                                <span className="text-sm font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-full">{item.count}</span>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* ================= 右侧：包含 Heat Map, Filter, 折线图的堆叠区域 (占 2/3 宽度) ================= */}
            {/* 使用 flex col 让它们在右侧垂直排列，并占满高度 */}
            <div className="md:col-span-2 flex flex-col gap-4 md:gap-6 h-full">

                {/* 1. 上方：Heat Map (占据右侧剩余空间的较大比例) */}
                <Card className="flex-[3] flex flex-col min-h-[250px] relative overflow-hidden">
                    <CardHeader className="absolute top-0 left-0 z-10">
                        <CardTitle className="text-white/90 shadow-sm">Heat Map</CardTitle>
                    </CardHeader>
                    {/* 这是一个 Heat Map 的占位符背景 */}
                    <div className="flex-1 bg-gradient-to-br from-blue-900 via-purple-900 to-red-900 opacity-80 flex items-center justify-center text-white/50 font-bold text-2xl tracking-widest">
                        MAP VISUALIZATION PLACEHOLDER
                    </div>
                </Card>

                {/* 2. 中间：过滤器输入框 (对应草图中间的 Customer/user/account icon 输入框) */}
                <div className="relative shrink-0">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input placeholder="Filter Customer / User / Account..." className="pl-9 bg-background" />
                </div>

                {/* 3. 下方：折线图 (固定一个合适的高度，或者按比例分配) */}
                <Card className="flex-[2] min-h-[250px] flex flex-col">
                    <CardHeader>
                        <CardTitle>折线图 Trend Analysis</CardTitle>
                    </CardHeader>
                    <CardContent className="flex-1 pl-0 -ml-4 pb-0">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={lineChartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--muted-foreground)/0.2)" />
                                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} dy={10} />
                                <YAxis axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} />
                                <Tooltip
                                    contentStyle={{ backgroundColor: 'hsl(var(--background))', borderColor: 'hsl(var(--border))' }}
                                    itemStyle={{ color: 'hsl(var(--foreground))' }}
                                />
                                <Line type="monotone" dataKey="value" stroke="hsl(var(--primary))" strokeWidth={2} dot={{r: 4, fill: 'hsl(var(--background))', strokeWidth: 2}} activeDot={{ r: 6 }} />
                            </LineChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

            </div>
        </div>
    );
};

export default DashboardPage;